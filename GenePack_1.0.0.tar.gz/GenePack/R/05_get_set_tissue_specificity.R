#' Get the tissue specificity list
#'
#' This function retrieves the list of tissues where the gene is 
#' specifically expressed.
#' 
#' @param object Gene object
#' @return the tissue specificity of the gene, or "-" if it was not specified 
#' at the creation.
#' @details This function is defined as a generic function to be applicable to 
#' any object that inherits from the Gene class.
#' 
#' @examples
#' gene_structure <- GenomicRanges::GRanges(seqnames = "chr1",
#'                   ranges = IRanges::IRanges(start = 200, end = 1200),
#'                   strand = "+")
#'                          
#' gene_product <- list(lncrna_id = "lncRNAID", 
#'                      lncrna_sequence = paste0(
#'                        "AUGCUUAGCGUACGGUAGGCUUAACUGCGUACGAUCGAUCG",
#'                        "GCUAAUCGGCUUAGCGUACGGUAGGCUUAACUGCGUACGAU",
#'                        "CGAUCGGCUAAGCGUACGGUAGGCUUAACUGCGUACGAUCG",
#'                        "AUCGGCUUAGCGUACGUAGGCUCAACUGCGUACGAUCGAUC",
#'                        "GGCUUAGCGUACGGUAGGCUUAACUGCGGACGAUCGAUCGG",
#'                        "CUUAGCGUACGGUAGGCUUAACUGCGUACGAUCGAUCGC"))
#'                                           
#' lncrna_gene <- createLncRNAGene(id = "ENST000001",
#'                hugo_symbol = "SYMBOL1",
#'                name = "lncRNA gene name",
#'                description = "gene description",
#'                tissue_specificity = list("liver", "small bowel"),
#'                gene_structure = gene_structure,
#'                gene_product = gene_product,
#'                clinical_significance = "association with disease")
#' 
#' @export


setGeneric("getTissues", function(object) {
  standardGeneric("getTissues")
})


#' @rdname getTissues
#' @export

setMethod("getTissues", "Gene", function(object) {
  object@tissue_specificity
})




#' Set the tissue specificity list
#'
#' This function sets the list of tissues where the gene is 
#' specifically expressed.
#' 
#' @param object Gene object.
#' @param value the new list of tissues.
#' @return the modified Gene object.
#' @details This function is defined as a generic function to be applicable to 
#' any object that inherits from the Gene class. After setting the new tissue 
#' specificity, the function checks that the Gene object is still 
#' valid by calling \code{validObject}.
#' 
#' @examples 
#' gene_structure <- GenomicRanges::GRanges(seqnames = "chr1",
#'                   ranges = IRanges::IRanges(start = 200, end = 1200),
#'                   strand = "+")
#'                          
#' gene_product <- list(lncrna_id = "lncRNAID", 
#'                      lncrna_sequence = paste0(
#'                        "AUGCUUAGCGUACGGUAGGCUUAACUGCGUACGAUCGAUCG",
#'                        "GCUAAUCGGCUUAGCGUACGGUAGGCUUAACUGCGUACGAU",
#'                        "CGAUCGGCUAAGCGUACGGUAGGCUUAACUGCGUACGAUCG",
#'                        "AUCGGCUUAGCGUACGUAGGCUCAACUGCGUACGAUCGAUC",
#'                        "GGCUUAGCGUACGGUAGGCUUAACUGCGGACGAUCGAUCGG",
#'                        "CUUAGCGUACGGUAGGCUUAACUGCGUACGAUCGAUCGC"))
#'                                           
#' lncrna_gene <- createLncRNAGene(id = "ENST000001",
#'                hugo_symbol = "SYMBOL1",
#'                name = "lncRNA gene name",
#'                description = "gene description",
#'                tissue_specificity = list("liver", "small bowel"),
#'                gene_structure = gene_structure,
#'                gene_product = gene_product,
#'                clinical_significance = "association with disease")
#' 
#' setTissues(lncrna_gene) <- list("liver", "large bowel")
#' 
#' getTissues(lncrna_gene)                                 
#' 
#' @export


setGeneric("setTissues<-", function(object, value) {
  standardGeneric("setTissues<-")
})


#' @rdname setTissues-set
#' @export

setMethod("setTissues<-", "Gene", function(object, value) {
  object@tissue_specificity <- value
  validObject(object)
  object
})
